

<?php $__env->startSection('title', 'Our Services - Training, Consultancy, Inspection, NDT & Calibration Services | ValidCert'); ?>
<?php $__env->startSection('description', 'Comprehensive industrial services including Training, Assessment, Consulting, NDT Services, Calibration Services, and Integrated Technical Support. Professional solutions for Energy, Industrial, and Construction sectors.'); ?>
<?php $__env->startSection('keywords', 'Industrial Services, Training Services, Consulting Services, NDT Services, Calibration Services, Assessment Services, Engineering Support, Industrial Solutions Pakistan'); ?>
<?php $__env->startSection('canonical', route('services')); ?>
<?php $__env->startSection('og_type', 'website'); ?>
<?php $__env->startSection('og_title', 'Our Services - Comprehensive Industrial Solutions'); ?>
<?php $__env->startSection('og_description', 'Comprehensive solutions across five core divisions: Training, Assessment, Consulting, NDT Services, Calibration Services, and Integrated Technical Support.'); ?>
<?php $__env->startSection('og_image', asset('assets/images/Training.webp')); ?>

<?php $__env->startSection('schema'); ?>
<script type="application/ld+json">
{
  "context": "https://schema.org",
  "type": "ItemList",
  "name": "ValidCert Services",
  "description": "Comprehensive industrial services offered by ValidCert",
  "itemListElement": [
    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    {
      "type": "ListItem",
      "position": <?php echo e($index + 1); ?>,
      "item": {
        "type": "Service",
        "name": "<?php echo e($service->title); ?>",
        "description": "<?php echo e(strip_tags($service->short_description ?? $service->description)); ?>",
        "url": "<?php echo e(route('service.detail', $service->slug)); ?>",
        "provider": {
          "type": "Organization",
          "name": "ValidCert"
        }
      }
    }<?php echo e(!$loop->last ? ',' : ''); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  ]
}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Services Hero Banner -->
<section class="hero-banner inner-banner">
    <div class="container">
        <div class="row row-gap-30 mt-50">
            <div class="col-lg-12 text-center">
                <h1 class="mb-20">
                    Our <span class="text-primary-theme">Services</span>
                </h1>
                <p class="text-white mb-20">
                    Comprehensive solutions in Training, Consultancy, Inspection, Procurement, and Engineering Support
                </p>
            </div>
        </div>
    </div>
</section>

<section class="our-services sec-gradiant">
    <div class="container">
        <div class="row row-gap-30 align-items-center">
            <div class="col-lg-3">
                <h3 class="hd-36">Our Services</h3>
            </div>
            <div class="col-lg-1">
                <div class="border-line sm"></div>
            </div>
            <div class="col-lg-8">
                <div class="border-line lg"></div>
            </div>
            <h2 class="sec-hd">
                Comprehensive <span>solutions</span> across five core divisions, delivering
                <span>excellence</span> in every project
            </h2>
            <p class="para fs-20 mb-70">Here are our services :</p>
        </div>
        <div class="row row-gap-40">
            <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-4 col-md-6">
                <div class="services-card-item position-relative">
                    <div class="services-card-wrapper">
                        <img src="<?php echo e($service->image ? asset($service->image) : asset('assets/images/Training.webp')); ?>" class="w-100 services-card-img position-relative"
                            alt="<?php echo e($service->title); ?>">
                        <img src="<?php echo e(asset('assets/images/shape-02.png')); ?>" class="services-card-shape" alt="shape-02">
                        <div class="services-card-content px-20 pt-20 z-1 position-relative">
                            <h3 class="hd-sm mb-10 text-primary-theme"><?php echo e($service->title); ?></h3>
                            <p class="para  mb-20">
                                <?php echo e($service->short_description ?? \Illuminate\Support\Str::limit(strip_tags($service->description), 100)); ?>

                            </p>
                        </div>

                        <div class="d-flex align-items-center justify-content-end">
                            <a href="<?php echo e(route('service.detail', $service->slug)); ?>" class="text-white fw-600 read-more-link">MORE <i class="fa-solid fa-angle-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <p class="text-center">No services available at the moment.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\validcert\resources\views/services.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card text-white bg-primary">
            <div class="card-body">
                <h5 class="card-title">Total Services</h5>
                <h2 class="mb-0"><?php echo e($stats['services']); ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-success">
            <div class="card-body">
                <h5 class="card-title">Total Bookings</h5>
                <h2 class="mb-0"><?php echo e($stats['bookings']); ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-warning">
            <div class="card-body">
                <h5 class="card-title">Pending Bookings</h5>
                <h2 class="mb-0"><?php echo e($stats['pending_bookings']); ?></h2>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-white bg-info">
            <div class="card-body">
                <h5 class="card-title">New Contacts</h5>
                <h2 class="mb-0"><?php echo e($stats['contact_submissions']); ?></h2>
            </div>
        </div>
    </div>
</div>

<!-- Recent Bookings -->
<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-calendar-check"></i> Recent Bookings</h5>
            </div>
            <div class="card-body">
                <?php if($recent_bookings->count() > 0): ?>
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Service</th>
                                <th>Name</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $recent_bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($booking->service->title ?? 'N/A'); ?></td>
                                <td><?php echo e($booking->name); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($booking->status === 'pending' ? 'warning' : ($booking->status === 'completed' ? 'success' : 'info')); ?>">
                                        <?php echo e(ucfirst($booking->status)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($booking->created_at->format('M d, Y')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <a href="<?php echo e(route('admin.bookings.index')); ?>" class="btn btn-sm btn-primary">View All</a>
                <?php else: ?>
                    <p class="text-muted">No bookings yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Recent Contacts -->
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5><i class="fas fa-envelope"></i> Recent Contact Submissions</h5>
            </div>
            <div class="card-body">
                <?php if($recent_contacts->count() > 0): ?>
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Subject</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $recent_contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($contact->name); ?></td>
                                <td><?php echo e(\Illuminate\Support\Str::limit($contact->subject, 30)); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($contact->status === 'new' ? 'danger' : 'secondary'); ?>">
                                        <?php echo e(ucfirst($contact->status)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($contact->created_at->format('M d, Y')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <a href="<?php echo e(route('admin.contacts.index')); ?>" class="btn btn-sm btn-primary">View All</a>
                <?php else: ?>
                    <p class="text-muted">No contact submissions yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\validcert\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
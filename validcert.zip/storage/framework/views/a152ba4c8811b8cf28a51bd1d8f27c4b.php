<form action="<?php echo e(route('contact.submit')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-12">
            <div class="field-wrapper">
                <input type="text" name="name" class="input-field" placeholder="Name" value="<?php echo e(old('name')); ?>" required>
                <div class="input-field-icon">
                    <i class="fa-solid fa-user"></i>
                </div>
            </div>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger mb-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
            <div class="field-wrapper">
                <input type="email" name="email" class="input-field" placeholder="Email" value="<?php echo e(old('email')); ?>" required>
                <div class="input-field-icon">
                    <i class="fa-solid fa-envelope"></i>
                </div>
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger mb-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
            <div class="field-wrapper">
                <input type="text" name="phone" class="input-field" placeholder="Phone Number" value="<?php echo e(old('phone')); ?>" required>
                <div class="input-field-icon">
                    <i class="fa-solid fa-phone"></i>
                </div>
            </div>
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger mb-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
            <div class="field-wrapper">
                <input type="text" name="subject" class="input-field" placeholder="Subject" value="<?php echo e(old('subject')); ?>" required>
                <div class="input-field-icon">
                    <i class="fa-solid fa-tag"></i>
                </div>
            </div>
            <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger mb-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
            <div class="field-wrapper">
                <textarea name="message" id="" class="text-area input-field" placeholder="Message" required><?php echo e(old('message')); ?></textarea>
                <div class="input-field-icon last-icon">
                    <i class="fa-solid fa-message"></i>
                </div>
            </div>
            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger mb-2"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
            <?php if(session('success')): ?>
                <div class="alert alert-success mb-3"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            
            <?php if(session('error')): ?>
                <div class="alert alert-danger mb-3"><?php echo e(session('error')); ?></div>
            <?php endif; ?>
            
            <button type="submit"
                class="btn btn-primary submit-btn d-flex justify-content-center align-items-center w-100 sec-btn">Send
                Message <span class="arrow-icon d-flex"><i
                        class="fa-solid fa-paper-plane"></i></span></button>
        </div>
    </div>
</form>

<?php /**PATH D:\xampp\htdocs\validcert\resources\views/components/contact-form.blade.php ENDPATH**/ ?>


<?php $__env->startSection('title', 'Services Management'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h1><i class="fas fa-cogs"></i> Services Management</h1>
    <a href="<?php echo e(route('admin.services.create')); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Add New Service
    </a>
</div>

<!-- Search Form -->
<form method="GET" action="<?php echo e(route('admin.services.index')); ?>" class="mb-4">
    <div class="row">
        <div class="col-md-6">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Search services..." value="<?php echo e(request('search')); ?>">
                <button type="submit" class="btn btn-outline-secondary">
                    <i class="fas fa-search"></i> Search
                </button>
                <?php if(request('search')): ?>
                    <a href="<?php echo e(route('admin.services.index')); ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-times"></i> Clear
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</form>

<!-- Services Table -->
<div class="card">
    <div class="card-body">
        <?php if($services->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Image</th>
                            <th>Status</th>
                            <th>Sort Order</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($service->id); ?></td>
                            <td><?php echo e($service->title); ?></td>
                            <td>
                                <?php if($service->image): ?>
                                    <img src="<?php echo e(asset($service->image)); ?>" alt="<?php echo e($service->title); ?>" style="width: 50px; height: 50px; object-fit: cover;">
                                <?php else: ?>
                                    <span class="text-muted">No image</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($service->is_active ? 'success' : 'secondary'); ?>">
                                    <?php echo e($service->is_active ? 'Active' : 'Inactive'); ?>

                                </span>
                            </td>
                            <td><?php echo e($service->sort_order); ?></td>
                            <td><?php echo e($service->created_at->format('M d, Y')); ?></td>
                            <td>
                                <a href="<?php echo e(route('admin.services.edit', $service)); ?>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <form action="<?php echo e(route('admin.services.destroy', $service)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this service?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash"></i> Delete
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-3">
                <?php echo e($services->links()); ?>

            </div>
        <?php else: ?>
            <p class="text-muted">No services found. <a href="<?php echo e(route('admin.services.create')); ?>">Create one now</a></p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\validcert\resources\views/admin/services/index.blade.php ENDPATH**/ ?>
@include('components.head')
@include('components.header')

@yield('content')

@include('components.footer')

